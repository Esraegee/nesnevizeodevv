﻿using System;

namespace Yemek_Tarifleri
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("**********Yemek Tarifi Uygluaması**********");

            YemekTarifi Tarif = new YemekTarifi();

            Console.WriteLine("Lütfen tarifini vermek istediğiniz yemeğin adını giriniz. : ");
            Tarif.YemekAdi = Console.ReadLine();

            Console.WriteLine("Şimdi malzemeleri giriniz : ");
            Tarif.Malzemeler = Console.ReadLine();

            Console.WriteLine("Nasıl Yapılıyor ? : ");
            Tarif.Yapilisi = Console.ReadLine();

            Console.WriteLine("***************************************");

            Tarif.tarifiGoster();

            Console.ReadKey();



        }
    }

    class YemekTarifi
    {
        public string YemekAdi { get; set; }
        public string Malzemeler { get; set; }
        public string Yapilisi { get; set; }

        public void tarifiGoster()
        {
            Console.WriteLine("Girilen yemeğin adı : {0}", YemekAdi);
            Console.WriteLine("Malzemeler : {0}", Malzemeler);
            Console.WriteLine("Yapılışı : {0}", Yapilisi);
        }

    }
}
